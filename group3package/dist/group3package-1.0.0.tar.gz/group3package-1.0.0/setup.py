# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['group3package']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'group3package',
    'version': '1.0.0',
    'description': 'Functions used for exploratory data analysis',
    'long_description': "# group3package\n\nFunctions used for exploratory data analysis\n\n## Installation\n\n```bash\n$ pip install group3package\n```\n\n```github\n1. Download repository\n2. Move into dist folder\n3. run 'pip install group3package-1.0.0-py3-none-any.whl'\n```\n\n## Usage\n\n- TODO\n\n## Contributing\n\nInterested in contributing? Check out the contributing guidelines. Please note that this project is released with a Code of Conduct. By contributing to this project, you agree to abide by its terms.\n\n## License\n\n`group3package` was created by Ryan Lazenby, Alex Khadra, Damien Fung. It is licensed under the terms of the MIT license.\n\n## Credits\n\n`group3package` was created with [`cookiecutter`](https://cookiecutter.readthedocs.io/en/latest/) and the `py-pkgs-cookiecutter` [template](https://github.com/py-pkgs/py-pkgs-cookiecutter).\n",
    'author': 'Ryan Lazenby, Alex Khadra, Damien Fung',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.8.6,<4.0.0',
}


setup(**setup_kwargs)
